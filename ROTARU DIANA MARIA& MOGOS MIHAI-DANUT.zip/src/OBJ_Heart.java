import javax.imageio.ImageIO;
import java.awt.*;
import java.io.IOException;

public class OBJ_Heart extends ObjectGatherable {

    GamePanel gp;



    public OBJ_Heart(GamePanel gp)  throws IOException {
        super();
        this.gp = gp;

        name = "Heart";

        image = ImageIO.read(getClass().getResourceAsStream("heart_full.png"));
        image2 = ImageIO.read(getClass().getResourceAsStream("heart_half.png"));
        image3 = ImageIO.read(getClass().getResourceAsStream("heart_blank.png"));
    }


    @Override
    public void gatherable() {

    }

    @Override
    public String toString() {
        return "";
    }

    }



