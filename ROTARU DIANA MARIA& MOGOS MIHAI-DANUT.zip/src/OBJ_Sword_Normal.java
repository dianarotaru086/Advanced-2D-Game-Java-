import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_Sword_Normal extends ObjectGatherable {

    GamePanel gp;
    Character character;


    public OBJ_Sword_Normal(GamePanel gp) throws IOException {

         this.gp = gp;

         gp.player.type = gp.player.type_pickUpOnly;

         name ="Normal Sword";
         image = ImageIO.read(getClass().getResourceAsStream("sword.png"));
         gp.player.attackValue = 2;


    }


    @Override
    public void gatherable() {

    }

    @Override
    public String toString() {
        return "";
    }
}
