import javax.swing.*;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        JFrame window = new JFrame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        window.setTitle("Adventure Game");

        GamePanel gamePanel = new GamePanel();
        KeyHandler keyH = new KeyHandler(gamePanel);
        window.add(gamePanel);

        window.pack();

        window.setLocationRelativeTo(null);
        window.setVisible(true);

        gamePanel.setupGame();

        gamePanel.startGameThread();

        GamePanel gp = new GamePanel();

        gamePanel.config.loadConfig();


        Player player = new Player("player", 3, 2,10,true,48,48,5);


        gp.obj = new ObjectGatherable[10];

        player.pickUpObjects(0, gp);
        player.pickUpObjects(1, gp);


    }
}
