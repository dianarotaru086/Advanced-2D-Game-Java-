import javax.imageio.ImageIO;
import java.io.IOException;

public class Grains extends ObjectGatherable{
    public Grains() throws IOException {
        super(2, Quality.common);

        name = "Grains";
        image = ImageIO.read(getClass().getResourceAsStream("food.png"));


    }
    public Grains(int quantity, Quality quality) {
        super(quantity,quality);
    }

    @Override
    public void gatherable() {
        System.out.println("Ai colectat" + quantity + " bucati de mancare, cu o calitate " + quality);
    }

    @Override
    public String toString() {
        return "Grains{" +
                "quantity=" + quantity +
                ", quality=" + quality +
                '}';
    }
}
