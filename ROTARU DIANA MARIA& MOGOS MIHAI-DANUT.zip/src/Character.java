import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public abstract class Character  {

    public String name;
    public int attack;
    public int defense;
    public int damage;
    public boolean status;
    public int maxSpeed;

    public Character currentWeapon;
    public Character currentShield;

    public int strength;
    public int dexterity;

    public int attackValue;
    public int defenseValue;

    public boolean alive = true;
    public boolean diying = false;
    int dyingCounter = 0;

    public final int type_pickUpOnly = 7;
    public int value;

    public int health;
    public List<ObjectGatherable> objects;
    protected int x, y;
    protected int speed;
    GamePanel gp;
    public int actionLockCounter = 0;

    public int maxLife;
    public boolean invincible = false;
    public int invincibleCounter = 0;

    public int type;
    public boolean attacking = false;

    public Rectangle attackArea = new Rectangle(0,0,0,0);


    public Rectangle solidArea;
    public int solidAreaDefaultX, solidAreaDefaultY;
    public boolean collisionOn = false;

    public BufferedImage up1, up2, down1, down2, left1, left2, right1, right2;
    public BufferedImage attackUp1, attackUp2, attackDown1, attackDown2, attackLeft1, attackLeft2, attackRight1, attackRight2;
    public BufferedImage zombie;
    public String direction = "down";

    public int spriteCounter = 0;
    public int spriteNum = 1;

    public BufferedImage image, image2, image3;
    public boolean collision = false;

    public int attackCounter = 0;


    public Character(String name, int attack, int defense, int damage, boolean status, int x, int y, int speed) {
        this.name = name;
        this.attack = attack;
        this.defense = defense;
        this.damage = damage;
        this.status = status;
        objects = new ArrayList<>();
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.solidArea = new Rectangle(10, 10, 48, 48);
    }

    public Character(GamePanel gp) {

    }

    public void setAction(){}
    public void update(){

        setAction();


        collisionOn = false;
        gp.cChecker.checkTile(this);
        gp.cChecker.checkEntity(this, gp.monster);
        boolean contactPlayer = gp.cChecker.checkPlayer(this);

        if(this.type == 2 && contactPlayer == true){
            if(gp.player.invincible == false){
                gp.player.health -=1;

            }
            gp.player.invincible = true;



            }


        if(invincible == true){
            invincibleCounter++;
            if(invincibleCounter > 40){
                invincible = false;
                invincibleCounter = 0;
            }
        }


    }

    public String getName() {
        return name;
    }

    public int getAttack() {
        return attack = strength * currentWeapon.attackValue;
    }

    public int getDefense() {
        return defense = dexterity * currentShield.defenseValue;
    }

    public int getDamage() {
        return damage;
    }

    public boolean status() {
        return status();
    }

    public List<ObjectGatherable> getObjects() {
        return objects;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public void setObjects(List<ObjectGatherable> objects) {
        this.objects = objects;
    }

    public void setAlive(boolean stare) {
        status = stare;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public abstract void damage(Character c);
    public abstract void die();
    public abstract void takeDamage(int damage);

    public void checkDrop(){

    }





    @Override
    public String toString() {
        return "Character{" +
                "name='" + name + '\'' +
                ", attack=" + attack +
                ", defense=" + defense +
                ", damage=" + damage +
                ", status=" + status +
                ", health=" + health +
                ", objects=" + objects +
                '}';
    }

    public BufferedImage resizeImage(BufferedImage originalImage, int width, int height) {
        Image temp = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        BufferedImage resizedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2d = resizedImage.createGraphics();
        g2d.drawImage(temp, 0, 0, null);
        g2d.dispose();

        return resizedImage;
    }

    public void draw(Graphics2D g2){
        BufferedImage image = null;

        switch (direction) {
            case "up":
                if(spriteNum == 1) {
                    image = up1;
                }
                if(spriteNum == 2){
                    image = up2;
                }
                break;

            case "down":
                if(spriteNum == 1) {
                    image = down1;
                }
                if(spriteNum == 2){
                    image = down2;
                }
                break;

            case "left":
                if(spriteNum == 1) {
                    image = left1;
                }
                if(spriteNum == 2){
                    image = left2;
                }
                break;

            case "right":
                if(spriteNum == 1) {
                    image = right1;
                }
                if(spriteNum == 2){
                    image = right2;
                }
                break;
        }




        if(invincible == true){
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
        }
        if(diying == true){ dyingAnimation(g2);
        }

        g2.drawImage(image, x,y, gp.tileSize, gp.tileSize, null);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
    }

    public void dyingAnimation(Graphics2D g2){
        dyingCounter++;
        if(dyingCounter <= 5){

            changeAlpha(g2,0f);
        }
        if(dyingCounter > 5 && dyingCounter <=10){
            changeAlpha(g2,1f);
        }
        if(dyingCounter > 10 && dyingCounter <=15){
            changeAlpha(g2,0f);
        }
        if(dyingCounter > 15 && dyingCounter <=20){
            changeAlpha(g2,1f);
        }
        if(dyingCounter > 20 && dyingCounter <=25){
            changeAlpha(g2,0f);
        }
        if(dyingCounter > 25 && dyingCounter <=30){
            changeAlpha(g2,1f);
        }
        if(dyingCounter > 30 && dyingCounter <=35){
            changeAlpha(g2,0f);
        }
        if(dyingCounter > 35 && dyingCounter <=40){
            changeAlpha(g2,1f);
        }
        if(dyingCounter >40){
            diying = false;
            alive = false;
        }


    }
    public void changeAlpha(Graphics2D g2, float alphaValue){
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alphaValue));
    }

    }



