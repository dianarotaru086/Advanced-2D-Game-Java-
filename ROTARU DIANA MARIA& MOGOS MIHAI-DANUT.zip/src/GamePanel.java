import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class GamePanel extends JPanel implements Runnable {

    final int originalTileSize = 20;
    final int scale = 3;


    public UI ui;

    final int tileSize = originalTileSize * scale;
    final int maxScreenCol = 20;
    final int maxScreenRow = 16;
    final int screenWidth = tileSize * maxScreenCol;
    final int screenHeight = tileSize * maxScreenRow;

    int FPS = 60;


    TileManager tileM = new TileManager(this);
    Thread gameThread;
    CollisionChecker cChecker = new CollisionChecker(this);
    AssetSetter aSetter = new AssetSetter(this);
    KeyHandler keyH = new KeyHandler(this);
    Player player = new Player(this, keyH,100, 100, 4);
    ObjectGatherable obj[] = new ObjectGatherable[10];
    public Enemy monster[] = new Enemy[20];
    ArrayList<Enemy> entityList = new ArrayList<>();

    public int[][] mapTileNum ;

    public Enemy enemy = new Enemy(this);

    public EventHandler eHandler = new EventHandler(this);

    public Buildings buildings = new Buildings(player,this);
    public EventHandler eventHandler = new EventHandler(this);

    public int gameState;
    public final int playState = 1;
    public final int pauseState = 2;
    public final int characterState = 4;

    Config config = new Config(this);



    public GamePanel() throws IOException {
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);
        ui = new UI(this);
        mapTileNum = new int[100][100];



    }


    public void setupGame() throws IOException {
        aSetter.setObject();
        aSetter.setMonster();
        gameState = playState;



    }

    public void startGameThread(){
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void setObject() {
        AssetSetter assetSetter = new AssetSetter(this);
        try {
            assetSetter.setObject();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean checkTileCollision(int x, int y) {
        int tileX = x / tileSize;
        int tileY = y / tileSize;

        int tile = mapTileNum[tileX][tileY];


        if (tile == 1 || tile == 2) {
            return true;
        }
        return false;
    }

    @Override
    public void run() {
        while(gameThread != null){
           double drawInterval = 1000000000/FPS;
           double nextDrawTime = System.nanoTime() + drawInterval;


            try {
                update();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            repaint();


            try {
                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime = remainingTime/1000000;

                if(remainingTime < 0){
                    remainingTime = 0;
                }

                Thread.sleep((long) remainingTime);

                nextDrawTime +=drawInterval;

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void update() throws IOException {

        if (gameState == playState) {
            player.update();
            enemy.update();

            for (int i = 0; i < monster.length; i++) {
                if (monster[i] != null) {
                    if(monster[i].alive == true && monster[i].diying == false){
                        monster[i].update();
                    }
                    if(monster[i].alive == false){
                        monster[i].checkDrop();
                        monster[i]= null;
                    }

                }
            }
        }
        if(gameState == pauseState){

        }
        if (keyH.constructiePressed) {

            Buildings buildings = new Buildings(player, this);
            buildings.player = player;
            buildings.gp = this;
            buildings.constructieFantana();
            keyH.constructiePressed = false;
        }

        if (keyH.monumentPressed) {

            Buildings buildings1 = new Buildings(player, this);
            buildings1.player = player;
            buildings1.gp = this;
            buildings1.constructieMonument();
            keyH.monumentPressed = false;
        }

        if(keyH.enterPressed){
            eventHandler.checkEvent();
            keyH.enterPressed = false;
        }

    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D)g;

        tileM.draw(g2);



        for (int i = 0; i < obj.length; i++) {
            if (obj[i] != null) {
                obj[i].draw(g2, this);
            }
        }


        entityList.clear();
        for (int i = 0; i < monster.length; i++) {
            if (monster[i] != null) {
                entityList.add(monster[i]);
            }
        }

        for (int i = 0; i < entityList.size(); i++) {
            entityList.get(i).draw(g2);
        }

        ui.draw(g2);

        player.draw(g2);


        g2.dispose();
    }

}
