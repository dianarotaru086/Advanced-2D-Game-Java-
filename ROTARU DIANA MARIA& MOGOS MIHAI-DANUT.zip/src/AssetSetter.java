import java.io.IOException;

public class AssetSetter {

    GamePanel gp;

    public AssetSetter(GamePanel gp){
        this.gp = gp;
    }


    public void setObject() throws IOException {
        gp.obj[0] = new Rock();
        gp.obj[0].x = 7 * gp.tileSize;
        gp.obj[0].y = 8 * gp.tileSize;


        gp.obj[1] = new Rock();
        gp.obj[1].x = 3 * gp.tileSize;
        gp.obj[1].y = 6 * gp.tileSize;

        gp.obj[2] = new Tree();
        gp.obj[2].x = 5 * gp.tileSize;
        gp.obj[2].y = 12 * gp.tileSize;

        gp.obj[3] = new Tree();
        gp.obj[3].x = 5 * gp.tileSize;
        gp.obj[3].y = 13 * gp.tileSize;

        gp.obj[4] = new Tree();
        gp.obj[4].x = 12 * gp.tileSize;
        gp.obj[4].y = 14 * gp.tileSize;

        gp.obj[5] = new Grains();
        gp.obj[5].x = 10 * gp.tileSize;
        gp.obj[5].y = 9 * gp.tileSize;

        gp.obj[6] = new Grains();
        gp.obj[6].x = 8 * gp.tileSize;
        gp.obj[6].y = 14 * gp.tileSize;

        gp.obj[7] = new Rock();
        gp.obj[7].x = 5 * gp.tileSize;
        gp.obj[7].y = 10 * gp.tileSize;

    }

    public void setMonster() throws IOException {


        gp.monster[0] = new Enemy(gp);
        gp.monster[0].x = 17 * gp.tileSize;
        gp.monster[0].y = 3 * gp.tileSize;

        gp.monster[1] = new Zombie(gp);
        gp.monster[1].x = 17 * gp.tileSize;
        gp.monster[1].y = 7 * gp.tileSize;

        gp.monster[2] = new Dragon(gp);
        gp.monster[2].x = 17 * gp.tileSize;
        gp.monster[2].y = 12 * gp.tileSize;





    }

}





