import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

public class Dragon extends Enemy{
    public Dragon(GamePanel gp) throws IOException {
        super(gp);

        name = "Dragon";
        speed = 1;
        maxLife = 6;
        health = maxLife;
        type = 2;

        attack = 3;
        defense = 0;
    }
    public void getImage() throws IOException {
        int w = gp.tileSize * 2;
        int h = gp.tileSize * 2;

        original = ImageIO.read(getClass().getResourceAsStream("drag.png"));

    }

    public void addObjectEnemy(String object){
        obiecte.add(object);
        System.out.println("Obiect adaugat in inventarul inamicului" + object);
    }

    public void dropObject(){

        if(health <= 0){
            die();

            if(!obiecte.isEmpty()){
                Random rand = new Random();
                int randomIndex = rand.nextInt(obiecte.size());
                String randomObject = obiecte.get(randomIndex);
                System.out.println( randomObject + "dropped.");
            } else {
                System.out.println("The inventory is empty");
            }
        }
    }

    public void draw(Graphics2D g2) {
        g2.drawImage(original, x, y, null);

        if(type == 2){

            double oneScale = (double) gp.tileSize/maxLife;
            double hBarValue = oneScale * health;

            g2.setColor( new Color( 35,35,35));
            g2.fillRect(x-1,y-16,gp.tileSize+2,12);

            g2.setColor( new Color(255,0, 30));
            g2.fillRect(x, y-15, (int) hBarValue, 10);
        }

        BufferedImage image = null;

        switch (direction) {
            case "up":
                if(spriteNum == 1) {
                    image = attackUp1;
                }
                if(spriteNum == 2){
                    image = attackUp2;
                }
                break;

            case "down":
                if(spriteNum == 1) {
                    image = attackDown1;
                }
                if(spriteNum == 2){
                    image = attackDown2;
                }
                break;

            case "left":
                if(spriteNum == 1) {
                    image = attackLeft1;
                }
                if(spriteNum == 2){
                    image = attackLeft2;
                }
                break;

            case "right":
                if(spriteNum == 1) {
                    image = attackRight1;
                }
                if(spriteNum == 2){
                    image = attackRight2;
                }
                break;
        }

        if(invincible == true){
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
        }
        if(diying == true){ dyingAnimation(g2);
        }

        g2.drawImage(image, x,y, gp.tileSize, gp.tileSize, null);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
    }

    public void dyingAnimation(Graphics2D g2){
        dyingCounter++;
        if(dyingCounter <= 5){

            changeAlpha(g2,0f);
        }
        if(dyingCounter > 5 && dyingCounter <=10){
            changeAlpha(g2,1f);
        }
        if(dyingCounter > 10 && dyingCounter <=15){
            changeAlpha(g2,0f);
        }
        if(dyingCounter > 15 && dyingCounter <=20){
            changeAlpha(g2,1f);
        }
        if(dyingCounter > 20 && dyingCounter <=25){
            changeAlpha(g2,0f);
        }
        if(dyingCounter > 25 && dyingCounter <=30){
            changeAlpha(g2,1f);
        }
        if(dyingCounter > 30 && dyingCounter <=35){
            changeAlpha(g2,0f);
        }
        if(dyingCounter > 35 && dyingCounter <=40){
            changeAlpha(g2,1f);
        }
        if(dyingCounter >40){
            diying = false;
            alive = false;
        }


    }
    public void changeAlpha(Graphics2D g2, float alphaValue){
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alphaValue));
    }



    public void update() {
        setAction();


        collisionOn = false;
        gp.cChecker.checkTile(this);
        gp.cChecker.checkEntity(this, gp.monster);
        boolean contactPlayer = gp.cChecker.checkPlayer(this);

        if(this.type == 2 && contactPlayer == true){
            if(gp.player.invincible == false){
                gp.player.health -=1;
                gp.player.invincible = true;
            }
        }

        if(invincible == true){
            invincibleCounter++;
            if(invincibleCounter > 40){
                invincible = false;
                invincibleCounter = 0;
            }
        }

    }

    public void checkDrop() {
        int i = new Random().nextInt(100)+1;

        if( i< 50){
            try {
                dropItem(new OBJ_Sword_Normal(gp));
                gp.player.pickUpObjects(gp.obj.length - 1, gp);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        if( i> 50 && i < 100 ){

            try {
                dropItem(new OBJ_Sheild_Wood(gp));
                gp.player.pickUpObjects(gp.obj.length - 1, gp);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
    }
    public void dropItem(ObjectGatherable droppedItem){
        for (int i = 0; i < gp.obj.length ; i++){
            if(gp.obj[i] == null){
                gp.obj[i] = droppedItem;
                gp.obj[i].x = this.x + gp.tileSize;
                gp.obj[i].y = this.y + gp.tileSize;

                break;
            }
        }
    }


}
