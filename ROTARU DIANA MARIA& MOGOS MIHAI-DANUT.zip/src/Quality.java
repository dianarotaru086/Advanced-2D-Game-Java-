public enum Quality {
    common(2), rare(4), epic(6);

    private final int rarity;

    Quality(int rarity) {
        this.rarity = rarity;
    }

    public int getRarity() {
        return rarity;
    }


}
