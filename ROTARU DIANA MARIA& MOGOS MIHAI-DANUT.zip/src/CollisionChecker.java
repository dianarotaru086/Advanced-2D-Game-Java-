import java.awt.*;

public class CollisionChecker {

    GamePanel gp;

    public CollisionChecker(GamePanel gp){
        this.gp = gp;
    }

    public void checkTile(Character c){
        if (c.solidArea == null) {
            c.solidArea = new Rectangle(0, 0, 48, 48);
        }


        int entityLeftWorldX = c.x + c.solidArea.x;
        int entityRightWorldX = c.x + c.solidArea.x + c.solidArea.width;
        int entityTopWorldY = c.y + c.solidArea.y;
        int entityBottomWorldY = c.y + c.solidArea.y + c.solidArea.height;


        int entityLeftCol = entityLeftWorldX/gp.tileSize;
        int entityRightCol = entityRightWorldX/gp.tileSize;
        int entityTopRow = entityTopWorldY/gp.tileSize;
        int entityBottomRow = entityBottomWorldY/gp.tileSize;

        entityLeftCol = Math.max(0, Math.min(entityLeftCol, gp.maxScreenCol - 1));
        entityRightCol = Math.max(0, Math.min(entityRightCol, gp.maxScreenCol - 1));
        entityTopRow = Math.max(0, Math.min(entityTopRow, gp.maxScreenRow - 1));
        entityBottomRow = Math.max(0, Math.min(entityBottomRow, gp.maxScreenRow - 1));

        int tileNum1, tileNum2;
        if (c.direction == null) {
            c.direction = "down";
        }

        switch (c.direction){
            case "up":
                entityTopRow = (entityTopWorldY - c.speed)/gp.tileSize;
                tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
                tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
                    c.collisionOn = true;
                }
                break;
            case "down":
                entityBottomRow = (entityBottomWorldY + c.speed) / gp.tileSize;
                tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
                tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
                    c.collisionOn = true;
                }
                break;
            case "left":
                entityLeftCol = (entityLeftWorldX - c.speed) / gp.tileSize;
                tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
                tileNum2 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
                if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
                    c.collisionOn = true;
                }
                break;
            case "right":
                entityRightCol = (entityRightWorldX + c.speed) / gp.tileSize;
                tileNum1 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
                    c.collisionOn = true;
                }
                break;

        }
    }

    public int checkObject(Character c, boolean player) {
        int index = 999;

        for (int i = 0; i < gp.obj.length; i++) {
            if (gp.obj[i] != null) {

                if (gp.obj[i].solidArea == null) {
                    gp.obj[i].solidArea = new Rectangle(0, 0, 48, 48);
                }


                c.solidArea.x = c.x + c.solidArea.x;
                c.solidArea.y = c.y + c.solidArea.y;
                gp.obj[i].solidArea.x = gp.obj[i].x + gp.obj[i].solidArea.x;
                gp.obj[i].solidArea.y = gp.obj[i].y + gp.obj[i].solidArea.y;


                switch (c.direction) {
                    case "up":
                        c.solidArea.y -= c.speed;
                        if (c.solidArea.intersects(gp.obj[i].solidArea)) {
                            if(gp.obj[i].collision == true){
                                c.collisionOn = true;
                            }
                            if(player == true){
                                index = i;
                            }
                        }
                        break;
                    case "down":
                        c.solidArea.y += c.speed;
                        if (c.solidArea.intersects(gp.obj[i].solidArea)) {
                            if(gp.obj[i].collision == true){
                                c.collisionOn = true;
                            }
                            if(player == true){
                                index = i;
                            }

                        }
                        break;
                    case "left":
                        c.solidArea.x -= c.speed;
                        if (c.solidArea.intersects(gp.obj[i].solidArea)) {
                            if(gp.obj[i].collision == true){
                                c.collisionOn = true;
                            }
                            if(player == true){
                                index = i;
                            }

                        }
                        break;
                    case "right":
                        c.solidArea.x += c.speed;
                        if (c.solidArea.intersects(gp.obj[i].solidArea)) {
                            if(gp.obj[i].collision == true){
                                c.collisionOn = true;
                            }
                            if(player == true){
                                index = i;
                            }

                        }
                        break;
                }



                c.solidArea.x = c.solidAreaDefaultX;
                c.solidArea.y = c.solidAreaDefaultY;
                gp.obj[i].solidArea.x = gp.obj[i].solidAreaDefaultX;
                gp.obj[i].solidArea.y = gp.obj[i].solidAreaDefaultY;
            }
        }
        return index;
    }

    public int checkEntity(Character c, Character[] target) {
        int index = 999;

        for (int i = 0; i < target.length; i++) {
            if (target[i] != null) {

                if (c.solidArea == null) c.solidArea = new Rectangle(0, 0, 48, 48);
                if (target[i].solidArea == null) target[i].solidArea = new Rectangle(0, 0, 48, 48);


                c.solidArea.x = c.x + c.solidArea.x;
                c.solidArea.y = c.y + c.solidArea.y;
                target[i].solidArea.x = target[i].x + target[i].solidArea.x;
                target[i].solidArea.y = target[i].y + target[i].solidArea.y;




                switch (c.direction) {
                    case "up":
                        c.solidArea.y -= c.speed;
                        break;
                    case "down":
                        c.solidArea.y += c.speed;
                        break;
                    case "left":
                        c.solidArea.x -= c.speed;
                        break;
                    case "right":
                        c.solidArea.x += c.speed;
                        break;
                }


                if (c.solidArea.intersects(target[i].solidArea)) {
                    c.collisionOn = true;
                    index = i;

                }


                c.solidArea.x = c.solidAreaDefaultX;
                c.solidArea.y = c.solidAreaDefaultY;
                target[i].solidArea.x = target[i].solidAreaDefaultX;
                target[i].solidArea.y = target[i].solidAreaDefaultY;
            }
        }

        return index;
    }

    public boolean checkPlayer(Character c){

        boolean contactPlayer = false;
        c.solidArea.x = c.x + c.solidArea.x;
        c.solidArea.y = c.y + c.solidArea.y;

        gp.player.solidArea.x = gp.player.x + gp.player.solidArea.x;
        gp.player.solidArea.y = gp.player.y + gp.player.solidArea.y;

        switch (c.direction) {
            case "up":
                c.solidArea.y -= c.speed;

                break;
            case "down":
                c.solidArea.y += c.speed;

                break;
            case "left":
                c.solidArea.x -= c.speed;

                break;
            case "right":
                c.solidArea.x += c.speed;

                break;
        }
        if(c.solidArea.intersects(gp.player.solidArea)){
            c.collisionOn = true;
            contactPlayer = true;
        }

        c.solidArea.x = c.solidAreaDefaultX;
        c.solidArea.y = c.solidAreaDefaultY;
        gp.player.solidArea.x = gp.player.solidAreaDefaultX;
        gp.player.solidArea.y = gp.player.solidAreaDefaultY;

        return contactPlayer;


    }




}



