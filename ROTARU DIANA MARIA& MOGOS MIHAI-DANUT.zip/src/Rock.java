import javax.imageio.ImageIO;
import java.io.IOException;

public class Rock extends ObjectGatherable{
    public Rock() throws IOException {
        super(3, Quality.common);

        name = "Rock";
        image = ImageIO.read(getClass().getResourceAsStream("stone.png"));

    }

    public Rock(int quantity, Quality quality)  {
        super(quantity, quality);

    }



    @Override
    public void gatherable() {
        System.out.println("Ai colectat" + quantity + " bucati de pietre, cu o calitate " + quality);
    }

    @Override
    public String toString() {
        return "Rock{" +
                "quantity=" + quantity +
                ", quality=" + quality +
                '}';
    }


}
