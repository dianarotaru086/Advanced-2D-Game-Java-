import javax.imageio.ImageIO;
import java.io.IOException;

public class Tree extends ObjectGatherable{
    public Tree() throws IOException {
        super(2, Quality.common);

        name = "Tree";
        image = ImageIO.read(getClass().getResourceAsStream("tree.png"));


    }
    public Tree(int quantity, Quality quality) {
        super(quantity,quality);
    }

    @Override
    public void gatherable() {
        System.out.println("Ai colectat" + quantity + " bucati de lemn, cu o calitate " + quality);
    }

    @Override
    public String toString() {
        return "Tree{" +
                "quantity=" + quantity +
                ", quality=" + quality +
                '}';
    }



}
