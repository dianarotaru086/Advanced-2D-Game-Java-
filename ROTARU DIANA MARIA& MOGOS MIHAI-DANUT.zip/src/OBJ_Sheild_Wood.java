import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_Sheild_Wood extends ObjectGatherable{
    public OBJ_Sheild_Wood(GamePanel gp) throws IOException {

        name ="Wood Shield";
        image =  ImageIO.read(getClass().getResourceAsStream("armor.png"));
        gp.player.defenseValue = 1;
    }


    @Override
    public void gatherable() {

    }

    @Override
    public String toString() {
        return "";
    }
}
