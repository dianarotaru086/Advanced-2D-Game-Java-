import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;

public abstract class ObjectGatherable {

    public int quantity;
    public Quality quality;

    public BufferedImage image, image2, image3;
    public String name;
    public boolean collision = false;
    public int x, y;
    public Rectangle solidArea = new Rectangle(0,0,48,48);
    public int solidAreaDefaultX = 0;
    public int solidAreaDefaultY = 0;

    public ObjectGatherable() {
    }

    public void draw(Graphics2D g2, GamePanel gp) {

        int screenX = x;
        int screenY = y;

        if (image != null) {
            g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);
        }




    }




    public abstract void gatherable();

    @Override
    public abstract String toString();

    public ObjectGatherable(int quantity, Quality quality) {
        this.quantity = quantity;
        this.quality = quality;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Quality getQuality() {
        return quality;
    }

    public void setQuality(Quality quality) {
        this.quality = quality;
    }
}
