import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Player extends Character{

    public int wood = 0;
    public int stone = 0;
    public int food = 0;
    public List<Item> inventory;

    GamePanel gp;
    KeyHandler keyH;
    Buildings buildings;
    EventHandler eventH;

    public boolean attackCanceled = false;

    public Player(GamePanel gp, KeyHandler keyH, int x, int y, int speed) throws IOException {
        super("PlayerName", 10, 5, 100, true, x, y, speed);
        this.gp = gp;
        this.keyH = keyH;



        solidArea = new Rectangle();
        solidArea.x = 8;
        solidArea.y = 16;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        solidArea.width = 32;
        solidArea.height = 32;

        attackArea.width = 36;
        attackArea.height = 36;


        setDefaultValues();
        getPlayerImage();
        getAttackImages();
    }

    public Player(String name, int attack, int defense, int health, boolean status, int x, int y, int speed) {
        super(name, attack, defense, health, status, x, y, speed);

        this.inventory = new ArrayList<>();


        if (inventory.isEmpty()) {
            inventory.add(new Item("Tree", 10, Quality.common));
            inventory.add(new Item("Rock", 5, Quality.rare));
            inventory.add(new Item("Grains", 3, Quality.epic));

        }


    }

    public void getAttackImages() throws IOException {
        attackUp1 = ImageIO.read(getClass().getResourceAsStream("boy_attack_up_1.png"));
        resizeImage(attackUp1, gp.tileSize, gp.tileSize);
        attackUp2 = ImageIO.read(getClass().getResourceAsStream("boy_attack_up_2.png"));
        resizeImage(attackUp2, gp.tileSize, gp.tileSize);
        attackDown1 = ImageIO.read(getClass().getResourceAsStream("boy_attack_down_1.png"));
        resizeImage(attackDown1, gp.tileSize, gp.tileSize);
        attackDown2 = ImageIO.read(getClass().getResourceAsStream("boy_attack_down_2.png"));
        resizeImage(attackDown2, gp.tileSize, gp.tileSize);
        attackLeft1 = ImageIO.read(getClass().getResourceAsStream("boy_attack_left_1.png"));
        resizeImage(attackLeft1, gp.tileSize, gp.tileSize);
        attackLeft2 = ImageIO.read(getClass().getResourceAsStream("boy_attack_left_2.png"));
        resizeImage(attackLeft2, gp.tileSize, gp.tileSize);
        attackRight1 = ImageIO.read(getClass().getResourceAsStream("boy_attack_right_1.png"));
        resizeImage(attackRight1, gp.tileSize, gp.tileSize);
        attackRight2 = ImageIO.read(getClass().getResourceAsStream("boy_attack_right_2.png"));
        resizeImage(attackRight2, gp.tileSize, gp.tileSize);

    }


    @Override
    public void damage(Character c) {
     c.takeDamage(attack);
     System.out.println("am avut atacuri: " + attack);
    }

    @Override
    public void die() {
        status = false;
        System.out.println("am murit! :(" + name);

    }

    @Override
    public void takeDamage(int damage) {
        int life = damage - defense;
        if(life > 0){
            health -=life;
            System.out.println("am ramas cu: " + life);
        }
        else System.out.println(" inca ma tin bine!");

        if(health <=0 ){
            die();
        }
    }

    public void colectWood(int q) {
        for (int i = 0; i < inventory.size(); i++) {
            if (inventory.get(i).nameItem.equals("wood")) {
                inventory.get(i).cresteCantitatea(q);

                return;
            }
            inventory.add(new Item("wood", q, Quality.common));
            System.out.println("Ai colectat " + q + " lemn. Total lemn: " + q);


        }
    }

    public void colectStone(int q){
        for (int i = 0; i < inventory.size(); i++) {
            if (inventory.get(i).nameItem.equals("stone")) {
                inventory.get(i).cresteCantitatea(q);

                return;
            }
            inventory.add(new Item("pietre", q, Quality.rare));
            System.out.println("Ai colectat " + q + " pietre. Total pietre: " + q);


        }


    }

    public void colectFood(int q){
        for (int i = 0; i < inventory.size(); i++) {
            if (inventory.get(i).nameItem.equals("grains")) {
                inventory.get(i).cresteCantitatea(q);

                return;
            }
            inventory.add(new Item("grains", q, Quality.common));
            System.out.println("Ai colectat " + q + " mancare. Total mancare: " + q);


        }


    }

    public void crafingObjects(){
        Item woodItem = null;
        Item stoneItem = null;

        for (Item item : inventory) {
            if (item.nameItem.equals("wood")) {
                woodItem = item;
            }
            if (item.nameItem.equals("stone")) {
                stoneItem = item;
            }
        }


        if (woodItem != null && stoneItem != null && woodItem.quantity >= 1 && stoneItem.quantity >= 1) {
            woodItem.cresteCantitatea(-1);
            stoneItem.cresteCantitatea(-1);
            System.out.println("S-a format un topor!");
        } else {
            System.out.println("Insuficiente materiale pentru a crea toporul!");
        }

    }

    public void setDefaultValues() throws IOException {
        x = 100;
        y = 100;
        speed = 4;
        direction = "down";

        maxLife = 6;
        health = maxLife;

        attackArea.width = 36;
        attackArea.height = 36;

        strength = 1;
        dexterity = 1;
        attack = getAttack();
        defense = getDefense();

        maxSpeed = 4;
        speed = maxSpeed;
    }



    public void update() {

        if (keyH.enterPressed == true && !attacking) {
            attacking = true;
            spriteCounter = 0;
        }

        if (attacking) {
            attacking();
        } else if (keyH.upPressed == true || keyH.downPressed == true || keyH.leftPressed == true || keyH.rightPressed == true) {

            if (keyH.upPressed) {
                direction = "up";
            } else if (keyH.downPressed == true) {
                direction = "down";
            } else if (keyH.leftPressed == true) {
                direction = "left";
            } else if (keyH.rightPressed == true) {
                direction = "right";
            }

            collisionOn = false;
            gp.cChecker.checkTile(this);

            int objIndex = gp.cChecker.checkObject(this, true);
            pickUpObjects(objIndex, gp);

            int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);
            contactMonster(monsterIndex);

            if (keyH.constructiePressed) {
                Buildings buildings = new Buildings(this, gp);
                buildings.player = this;
                buildings.gp = gp;
                buildings.constructieFantana();
                keyH.constructiePressed = false;
            }

            if (keyH.monumentPressed) {
                Buildings buildings1 = new Buildings(this, gp);
                buildings1.player = this;
                buildings1.gp = gp;
                buildings1.constructieMonument();
                keyH.monumentPressed = false;
            }

            gp.eHandler.checkEvent();

            if (!collisionOn && !keyH.enterPressed) {

                switch (direction) {
                    case "up":
                        y -= speed;
                        break;
                    case "down":
                        y += speed;
                        break;
                    case "left":
                        x -= speed;
                        break;
                    case "right":
                        x += speed;
                        break;
                }
            }

            if(keyH.enterPressed && attackCanceled == false){
                attacking = true;
                spriteCounter = 0;
            }
            attackCanceled = false;


            spriteCounter++;
            if (spriteCounter > 12) {
                if (spriteNum == 1) {
                    spriteNum = 2;
                } else if (spriteNum == 2) {
                    spriteNum = 1;
                }
                spriteCounter = 0;
            }
        }

        if (invincible) {
            invincibleCounter++;
            if (invincibleCounter > 60) {
                invincible = false;
                invincibleCounter = 0;
            }
        }

        gp.cChecker.checkTile(this);
        int objectIndex = gp.cChecker.checkObject(this, true);
        int entityIndex = gp.cChecker.checkEntity(this, gp.monster);
    }

    public void attacking() {
        spriteCounter++;

        if (spriteCounter <= 5) {
            spriteNum = 1;
        } else if (spriteCounter <= 25) {
            spriteNum = 2;

            int currentX = x;
            int currentY = y;
            int solidWidth = solidArea.width;
            int solidHeight = solidArea.height;


            switch (direction) {
                case "up":
                    y -= attackArea.height;
                    break;
                case "down":
                    y += attackArea.height;
                    break;
                case "left":
                    x -= attackArea.width;
                    break;
                case "right":
                    x += attackArea.width;
                    break;
            }

            solidArea.width = attackArea.width;
            solidArea.height = attackArea.height;


            int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);
            damageMonster(monsterIndex);


            x = currentX;
            y = currentY;
            solidArea.width = solidWidth;
            solidArea.height = solidHeight;
        } else {
            spriteNum = 1;
            spriteCounter = 0;
            attacking = false;
        }
    }

    public void draw(Graphics2D g2){
        BufferedImage image = null;
        int tempScreenX = x;
        int tempScreenY = y;

        switch (direction) {
            case "up":
                if(attacking == false){
                    if(spriteNum == 1) {
                        image = up1;
                    }
                    if(spriteNum == 2){
                        image = up2;
                    }
                }
                if(attacking == true){
                    tempScreenY = y -gp.tileSize;
                    if(spriteNum == 1) {
                        image = attackUp1;
                    }
                    if(spriteNum == 2){
                        image = attackUp2;
                    }
                }

                break;

            case "down":
                if(attacking == false){
                    if(spriteNum == 1) {
                        image = down1;
                    }
                    if(spriteNum == 2){
                        image = down2;
                    }
                }
                if(attacking == true){
                    if(spriteNum == 1) {
                        image = attackDown1;
                    }
                    if(spriteNum == 2){
                        image = attackDown2;
                    }
                }
                break;

            case "left":
                if(attacking == false){
                    if(spriteNum == 1) {
                        image = left1;
                    }
                    if(spriteNum == 2){
                        image = left2;
                    }
                }
                if(attacking == true){
                    tempScreenX = x -gp.tileSize;
                    if(spriteNum == 1) {
                        image = attackLeft1;
                    }
                    if(spriteNum == 2){
                        image = attackLeft2;
                    }
                }
                break;

            case "right":
                if(attacking == false){
                    if(spriteNum == 1) {
                        image = right1;
                    }
                    if(spriteNum == 2){
                        image = right2;
                    }
                }
                if(attacking == true){
                    if(spriteNum == 1) {
                        image = attackRight1;
                    }
                    if(spriteNum == 2){
                        image = attackRight2;
                    }
                }
                break;
        }

        if (invincible) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
        }

        g2.drawImage(image, tempScreenX, tempScreenY, gp.tileSize, gp.tileSize, null);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
    }


    public void diyingAnimation(){
        dyingCounter ++;

        if(dyingCounter <=5){

        }
    }

    public void getPlayerImage(){
        try{

            up1 = ImageIO.read(getClass().getResourceAsStream("boy_up_1.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("boy_up_2.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("boy_down_1.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("boy_down_2.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("boy_left_1.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("boy_left_2.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("boy_right_1.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("boy_right_2.png"));




        }catch (IOException e){
            e.printStackTrace();
        }
    }


    @Override
    public String toString() {
        return "INVENTAR: " +
                "wood=" + wood +
                ", stone=" + stone +
                ", food=" + food +
                '}';
    }
    public void pickUpObjects(int i, GamePanel gp) {

        if (i != 999 && gp.obj[i] != null) {

            ObjectGatherable object = gp.obj[i];

            String objectName = object.name;
            int quantityFound = object.getQuantity();

            if (objectName == null) {
                return;
            }

            if (inventory == null) {
                inventory = new ArrayList<>();
            }

            boolean found = false;
            for (Item item : inventory) {
                if (item.nameItem.equals(objectName)) {
                    item.cresteCantitatea(quantityFound);
                    found = true;
                    System.out.println(objectName + " colectat! Cantitate totală: " + item.quantity);
                    break;
                }
            }

            if (!found) {
                Quality quality = determineQuality(objectName);
                inventory.add(new Item(objectName, quantityFound, quality));
                System.out.println(objectName + " colectat!");
            }

            Item.sortInventory(inventory);


            System.out.println("Inventar sortat:");
            for (int j = 0; j < inventory.size(); j++) {
                System.out.println(inventory.get(j));
            }

            gp.obj[i] = null;
        }

    }

    public int getResourceQuantity(String resourceName) {
        if (inventory == null) {
            System.out.println("Inventarul este null!");
            return 0;
        }



        for (Item item : inventory) {

            if (item.nameItem.equals(resourceName)) {
                return item.quantity;
            }
        }

        System.out.println("Resursa " + resourceName + " nu a fost găsită!"); // Debug
        return 0;
    }


    public void updateResourceQuantity(String resourceName, int amount) {
        if (inventory == null) {
            System.out.println("Inventarul este null, nu se poate actualiza!");
            return;
        }

        for (Item item : inventory) {
            if (item.nameItem.equals(resourceName)) {
                item.cresteCantitatea(amount);
                System.out.println("Cantitatea de " + resourceName + " a fost actualizată: " + item.quantity);
                return;
            }
        }
    }


    public void showInventory() {
        for (Item item : inventory) {
            System.out.println("Obiect: " + item.nameItem + " | Cantitate: " + item.quantity);
        }
    }

    public Quality determineQuality(String objectName) {
        switch (objectName) {
            case "Tree":
                return Quality.common;
            case "Rock":
                return Quality.rare;
            case "Grains":
                return Quality.epic;
            default:
                return Quality.common;
        }
    }

    public void contactMonster(int i){

        if( i != 999){

            if(invincible == false){

                int damage = attack - gp.monster[i].attack - defense;
                if(damage < 0){
                    damage = 0;
                }

                health -=1;
                invincible = true;
            }



        }

    }
    public int getAttack() {
        return attack = strength;
    }

    public int getDefense() {
        return defense = dexterity;
    }

    public void damageMonster(int i){
        if(i != 999){
            if(gp.monster[i].invincible == false){

                int damage = attack - gp.monster[i].defense;
                if(damage < 0){
                    damage = 0;
                }
                gp.monster[i].health -= damage;
                gp.monster[i].invincible = true;

                if(gp.monster[i].health <=0){
                    gp.monster[i].diying = true;
                }
            }
        }
    }

    public void interactMonster(int i){
        if( gp.keyH.enterPressed == true){
            if( i != 999){
                attackCanceled = false;
                attacking = true;
            }
        }
    }


}