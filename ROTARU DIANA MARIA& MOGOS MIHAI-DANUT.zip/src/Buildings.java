import java.awt.event.KeyEvent;

public class Buildings {

    Player player;
    GamePanel gp;
    KeyHandler keyH;
    private Object KeyEvent;
    boolean fountainBuilt = false;

    public Buildings(Player player, GamePanel gp) {
        this.player = player;
        this.gp = gp;
    }

    public void constructieFantana() {


        System.out.println("Wood: " + player.getResourceQuantity("Tree") + " Stone: " + player.getResourceQuantity("Rock"));

        if (player.getResourceQuantity("Tree") >= 1 && player.getResourceQuantity("Rock") >= 2) {
            int tileX = player.x / gp.tileSize;
            int tileY = player.y / gp.tileSize;

            if (gp.tileM.mapTileNum[tileX][tileY] == 0) {
                gp.tileM.mapTileNum[tileX][tileY] = 7;

                player.updateResourceQuantity("Tree", -1);
                player.updateResourceQuantity("Rock", -2);
                fountainBuilt = true;
                System.out.println("Fântâna a fost construită!");
            } else {
                System.out.println("Nu se poate construi aici!");
            }
        } else {
            System.out.println("Materiale insuficiente!");
        }
    }

    public void constructieMonument() {


        System.out.println("Wood: " + player.getResourceQuantity("Tree") + " Stone: " + player.getResourceQuantity("Rock"));

        if (player.getResourceQuantity("Tree") >= 2 && player.getResourceQuantity("Rock") >= 3) {
            int tileX = player.x / gp.tileSize;
            int tileY = player.y / gp.tileSize;

            if (gp.tileM.mapTileNum[tileX][tileY] == 0) {
                gp.tileM.mapTileNum[tileX][tileY] = 8;

                player.updateResourceQuantity("Tree", -2);
                player.updateResourceQuantity("Rock", -3);
                System.out.println("Monumentul a fost construit!");
            } else {
                System.out.println("Nu se poate construi aici!");
            }
        } else {
            System.out.println("Materiale insuficiente!");
        }
    }

}
