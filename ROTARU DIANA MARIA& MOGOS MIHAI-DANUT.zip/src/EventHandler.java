import java.awt.*;

public class EventHandler {

    GamePanel gp;
    Buildings buildings;
    Player player;

    EventRect eventRect[][];

    public EventHandler(GamePanel gp) {
        this.gp = gp;
        this.buildings = gp.buildings;
        this.player = gp.player;
        eventRect = new EventRect[gp.maxScreenCol][gp.maxScreenCol];

        int col = 0;
        int row = 0;
        while (col < gp.maxScreenCol && row < gp.maxScreenRow) {
            eventRect[col][row] = new EventRect();
            eventRect[col][row].x = 23;
            eventRect[col][row].y = 23;
            eventRect[col][row].width = 2;
            eventRect[col][row].height = 2;
            eventRect[col][row].eventRectDefaultX = eventRect[col][row].x;
            eventRect[col][row].eventRectDefaultY = eventRect[col][row].y;

            col++;
            if (col == gp.maxScreenCol) {
                col = 0;
                row++;
            }
        }


    }


    public void checkEvent() {

        if (hit(6, 5, "any")) {
            fantanaVietii(gp.gameState);
        }

        if(hit(11,5,"any")){
            statuiaVietii(gp.gameState);
        }


        if(hit(14,6,"any")){
            fantanaVietii(gp.gameState);
        }


    }

    public boolean hit(int col, int row, String reqDirection) {
        boolean hit = false;

        gp.player.solidArea.x += gp.player.x;
        gp.player.solidArea.y += gp.player.y;
        eventRect[col][row].x = col * gp.tileSize + eventRect[col][row].x;
        eventRect[col][row].y = row * gp.tileSize + eventRect[col][row].y;

        if (gp.player.solidArea.intersects(eventRect[col][row]) && !eventRect[col][row].eventDone) {
            if (gp.player.direction.contentEquals(reqDirection) || reqDirection.contentEquals("any")) {
                hit = true;
            }
        }

        gp.player.solidArea.x = gp.player.solidAreaDefaultX;
        gp.player.solidArea.y = gp.player.solidAreaDefaultY;
        eventRect[col][row].x = eventRect[col][row].eventRectDefaultX;
        eventRect[col][row].y = eventRect[col][row].eventRectDefaultY;

        return hit;
    }


    public void damagePit(int gameState) {
        gp.gameState = gameState;
        gp.player.health -= 1;

    }

    public void fantanaVietii(int gameState) {

        if (gp.keyH.enterPressed == true) {
            gp.gameState = gameState;
            gp.player.attackCanceled = true;
            gp.player.health = gp.player.maxLife;
            System.out.println("viata a fost refacuta!");

        }

    }

    public void statuiaVietii(int gameState) {

        if (gp.keyH.enterPressed == true) {
            gp.gameState = gameState;
            gp.player.attackCanceled = true;
            gp.player.health = gp.player.maxSpeed;
            System.out.println("Viteza este la maxim. Profita de ea!");

        }

    }
}








