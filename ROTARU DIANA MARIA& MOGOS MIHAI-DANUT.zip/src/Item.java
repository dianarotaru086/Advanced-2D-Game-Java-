import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Item {
    public String nameItem;
    public Quality quality;
    public int itemAttack;
    public int itemDefense;
    public int durability;
    public int quantity;


    public Item(String nameItem, Quality quality, int quantity) {
        this.nameItem = nameItem;
        this.quality = quality;
        this.itemAttack = itemAttack;
        this.itemDefense = itemDefense;
        this.durability = quality.getRarity();
        this.quantity = quantity;
    }

    public Item(String nameItem, int quantity, Quality quality){
        this.nameItem = nameItem;
        this.quantity = quantity;
        this.quality = quality;
    }


    public static Comparator<Item> sort = new Comparator<Item>() {
        @Override
        public int compare(Item item1, Item item2) {
            return item1.nameItem.compareTo(item2.nameItem);
        }
    };


    public static void sortInventory(List<Item> inventory) {
        Collections.sort(inventory, sort);
    }



    public void cresteCantitatea(int q){
        this.quantity += q;
    }

    @Override
    public String toString() {
        return "Item{" +
                "nameItem='" + nameItem + '\'' +
                ", quality=" + quality +
                ", quantity=" + quantity +
                '}';
    }
}
